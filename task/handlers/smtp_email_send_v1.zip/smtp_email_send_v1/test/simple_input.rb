{
  'info' => {
    'server' => '',
    'port' => '',
    'tls' => '',
    'username' => '',
    'password' => ''
  },
  'parameters' => {
    'error_handling'          => 'Error Message',
    'from'                    => '',
    'to'                      => '',
    'subject'                 => '',
    'htmlbody'                => '',
    'textbody'                => ''
  }
}
